<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>giga meeting</title>
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Style custom CSS -->
  <link rel="stylesheet" href="vendor/bootstrap/css/style.css">
  <!-- google fonts -->
  <link href="https://fonts.googleapis.com/css?family=Philosopher&display=swap" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light static-top" style="background-color: #2699FB">
    <div class="container">
      <a class="navbar-brand" href="index.html"
        style="font-family: 'Philosopher', sans-serif; font-size: 28px; color: white">giga meeting</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
        aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="vendor/login form.php" style="font-size: 15px;">Sign in / Register</a>
          </li>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h1 class="mt-5" style="font-family: 'Philosopher', sans-serif;">Welcome to the <strong
            style="font-size: 48px">giga meeting</strong></p>
          <ul class="list-unstyled">
            <h5>Book your meeting room in an easy way.</h5>
          </ul>
      </div>
    </div>

    <br><br>

    <div class="row">
      <div class="offset-lg-2 col-lg-8 offset-lg-2">
        <h5>Check availability</h5>
        <hr>
      </div>
    </div>

    <div class="form-row">
	  
	   <div class="form-group offset-md-2 col-md-2">
        <label for="inputState">Check-in date</label>
		<input type="date" class="form-control" id="inputCity">
      </div>

      <div class="form-group col-md-2">
        <label for="inputState">Duration</label>
        <select id="inputState" class="form-control">
          <option selected>1 hrs</option>
          <option>2 hrs</option>
          <option>3 hrs</option>
        </select>
      </div>

      <div class="form-group col-md-2">
        <label for="inputState">Guests</label>
        <select id="inputState2" class="form-control">
          <option selected>1 - 6</option>
          <option>1 - 12</option>
          <option>1 - 18</option>
        </select>
      </div>

      <div class="col-md-2" style="margin-top: 32px;">
		<li><a href="available.html" ><i class="fas fa-sign-out-alt"></i> Search</a></li>
      </div>
    </div>

    <br><br>


    <div class="offset-lg-2 col-lg-8 offset-lg-2">
      <h5>Available list</h5>
    </div>

    <div class="row">
      <div class="offset-md-2 col-md-8">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">SL</th>
              <th scope="col">Room No.</th>
              <th scope="col">Time</th>
              <th scope="col">Status</th>
              <th scope="col">Remarks</th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td>Room 1</td>
              <td>10.00 am- 11.oo am</td>
              <td>@mdo</td>
              <td>
                <select id="inputState" class="form-control">
                  <option selected>Projector</option>
                  <option>Laptop</option>
                </select>
              </td>
              <td>
                <li><a href="sucessful.html" ><i class="fas fa-sign-out-alt"></i> Booking</a></li>
              </td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Room 2</td>
              <td>11.00 am- 12.00 am</td>
              <td>@fat</td>
              <td>
                <select id="inputState" class="form-control">
                  <option selected>Projector</option>
                  <option>Laptop</option>
                </select>
              </td>
              <td>
                <li><a href="sucessful.html" ><i class="fas fa-sign-out-alt"></i> Booking</a></li>
              </td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Room 3</td>
              <td>12.00 pm - 01.00 pm</td>
              <td>@twitter</td>
              <td>
                <select id="inputState" class="form-control">
                  <option selected>Projector</option>
                  <option>Laptop</option>
                </select>
              </td>
              <td>
                <li><a href="sucessful.html" ><i class="fas fa-sign-out-alt"></i> Booking</a></li>
              </td>
            </tr>
            <tr>
              <th scope="row">4</th>
              <td>Room 4</td>
              <td>2.00 pm - 3.00 pm</td>
              <td>@mdo</td>
              <td>
                <select id="inputState" class="form-control">
                  <option selected>Projector</option>
                  <option>Laptop</option>
                </select>
              </td>
              <td>
                <li><a href="sucessful.html" ><i class="fas fa-sign-out-alt"></i> Booking</a></li>
              </td>
            </tr>
            <tr>
              <th scope="row">5</th>
              <td>Room 5</td>
              <td>4.00 pm - 5.00 pm</td>
              <td>@fat</td>
              <td>
                <select id="inputState" class="form-control">
                  <option selected>Projector</option>
                  <option>Laptop</option>
                </select>
              </td>
              <td>
                <li><a href="sucessful.html" ><i class="fas fa-sign-out-alt"></i> Booking</a></li>
              </td>
            </tr>
            
              
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <br>

  <!-- Footer -->
  <footer class="page-footer font-small blue">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">
      <a href="#"> <strong style="font-family:'Philosopher', sans-serif;"> giga meeting.</strong></a>
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
